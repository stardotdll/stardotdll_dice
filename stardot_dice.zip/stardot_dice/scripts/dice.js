Hooks.once('diceSoNiceReady', (dice3d) => {
    dice3d.addSystem({ id: "stardotdll", name: "stardotdll"}, true); 
    dice3d.addDicePreset({
      type: "d20",
      labels: [
        // "modules/stardotdll_dice/images/nat1.png"
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        "10",
        "11",
        "12",
        "13",
        "14",
        "15",
        "16",
        "17",
        "18",
        "19",
        "modules/stardotdll_dice/images/nat20.png"
      ],
      bumpMaps: [
       // "modules/stardotdll_dice/images/nat1_BUMP.png"
        ,
        ,
        ,
        ,
        ,
        ,
        ,
        ,
        ,
        ,
        ,
        ,
        ,
        ,
        ,
        ,
        ,
        ,
        ,
        "modules/stardotdll_dice/images/nat20_BUMP.png"
      ],
      system: "stardotdll"
    },"d20");

    dice3d.addDicePreset({
      type: "d2",
      labels: [
        "†",
        "modules/stardotdll_dice/images/nat20.png"
      ],
      bumpMaps: [
        ,
        "modules/stardotdll_dice/images/nat20_BUMP.png"
      ],
      system: "stardotdll"
    },"d2");
   
    dice3d.addDicePreset({
      type: "d4",
      labels: [
        "†",
        "2",
        "3",
        "4"
      ],
      system: "stardotdll"
    },"d4");
   
    dice3d.addDicePreset({
      type: "d6",
      labels: [
        "†",
        "2",
        "3",
        "4",
        "5",
        "6"
      ],
      system: "stardotdll"
    },"d6");
   
    dice3d.addDicePreset({
      type: "df",
      labels: [
        "†",
        "",
        "☀"
      ],
      system: "stardotdll",
      fontScale: 1.3
    },"df");
      
    dice3d.addDicePreset({
      type: "d8",
      labels: [
        "†",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8"
      ],
      system: "stardotdll"
    },"d8");
      
    dice3d.addDicePreset({
      type: "d10",
      labels: [
        "†",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        "10"
      ],
      system: "stardotdll" 
    },"d10");
   
    dice3d.addDicePreset({
      type: "d12",
      labels: [
        "†",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        "10",
        "11",
        "12"
      ],
      system: "stardotdll"
    },"d12");
      
    dice3d.addDicePreset({
      type: "d100",
      labels: [
        "10",
        "20",
        "30",
        "40",
        "50",
        "60",
        "70",
        "80",
        "90",
        "00",
      ],
      system: "stardotdll"
    },"d100");

  //  dice3d.addTexture("stardotdll", {
  //      name: "stardotdll",
  //      composite: "source-over",
  //      source: "modules/arkangel/images/arkangel-texture.png",
  //      bump:"modules/arkangel/images/arkangel-texture_bump.png" //puoi anche lasciarla vuoto
  //  });
  });